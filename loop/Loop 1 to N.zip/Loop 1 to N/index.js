
let N=prompt("enter the number");

for(let i=1; i<=N ; i++){
    console.log(i);
}

