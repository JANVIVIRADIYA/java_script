let num1=20
let num2=7
let num3=10

if(num1>num2 && num1>num3){
    console.log("num1 is largest number");

}
else if(num2>num3){
    console.log("num2 is largest number");
}
else{
    console.log("num3");
}