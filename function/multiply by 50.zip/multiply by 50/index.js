function mul(number){
   let result=number*50;
   console.log(result);
}
let number=2
mul(number);