let num1=30
let num2=60


 if(num1>num2){
    console.log(true);
 }
 else{
    console.log(false);
 }

 if(num1<num2){
    console.log(true);
 }
 else{
    console.log(false);
 }

 if(num1==num2){
    console.log(true);
 }
 else{
    console.log(false);
 }