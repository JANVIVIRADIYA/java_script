let a=15
let b=17
let c=3

 let remainder=(a+b)/c

 console.log(remainder);