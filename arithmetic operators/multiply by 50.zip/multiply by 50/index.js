let a=2

 console.log(a*50);