let one=6
let two=7
let three=8
let four=4
let five=9 
let ans=(one+two+three+four+five)

console.log(ans);
console.log(ans*2);
