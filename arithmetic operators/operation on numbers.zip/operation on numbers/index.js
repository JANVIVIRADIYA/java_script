let number = 4
number *= 3
number += 7
number -= 10
console.log(number);
