alert("hello Welcome to JavaScript");

let a=5
let b='java'

console.log(a);

console.log(typeof(a));


console.log(b);

console.log(typeof(b));