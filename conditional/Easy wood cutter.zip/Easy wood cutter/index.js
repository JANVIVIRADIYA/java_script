let N=30

if(N%3==0){
    console.log("yes");
}
else{
    console.log("no");
}