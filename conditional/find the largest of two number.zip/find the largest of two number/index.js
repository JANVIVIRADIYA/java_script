let num1=8
let num2=8

if(num1>num2){
    console.log("num1 is largest number");

}
else if(num1<num2){
    console.log("num2 is largest number");
}
else{
    console.log("num1 and num2 are equal");
}