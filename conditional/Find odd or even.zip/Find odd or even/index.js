let number=4;
if(number%2==0){
   console.log("it's an even number");
}else{
   console.log("it's an odd number");
}
