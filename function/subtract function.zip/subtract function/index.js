function subtract(a,b,c,d){
    console.log(a-b-c-d);
}
subtract(50,10,4,6)