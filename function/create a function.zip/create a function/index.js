function sum(x,y,z){
    console.log(x+y+z);
 }
 sum(4,7,3)