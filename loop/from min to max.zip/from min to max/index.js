
let max=19
let min=14

for(let i=min; i<max; i++){
    console.log(i);
}

console.log("-------------Q=2-----------");

let max2=10
let min2=6
for(let i=min2; i<=max2; i++){
    console.log(i);
}

