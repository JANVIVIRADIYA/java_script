   console.log( " 1 (first question)");

let x=20
let y=15

x+=y;
y=x-y;
x-=y;
console.log("x=",x,"y=",y);


console.log( "2 (second question)");

let a=20
let b=35
let c=29
let d=30
let e=39
let sum=(a+b+d) -(c+e)

console.log(sum);







console.log("3 (third question)");

console.log("------Report card------");
console.log('student name:JS');
console.log('grade:8');
console.log('----------------------');
console.log('subject    score    grade');
console.log('----------------------');
console.log('math       90       A+');
console.log('math       85       A+');
console.log('math       92       A');
console.log('math       88       A+');
console.log('math       82       A');
console.log('----------------------');
console.log('total marks:437');
console.log('Average marks 87.4');
console.log('----------------------');
