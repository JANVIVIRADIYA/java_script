let a=4
let b=5
let c=8
let d=9
let e=10
let f=2
let g=3
let remainder=((a+b+c)*(d+e+f+g));
console.log(remainder);
