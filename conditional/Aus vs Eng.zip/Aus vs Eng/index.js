let Australia=46
let England=67

// let speed = distance/time
// console.log(speed);

if(Australia > England){
    console.log("Australia");
}
else if(Australia < England){
    console.log("England");
}
else{
    console.log("Tie");
}