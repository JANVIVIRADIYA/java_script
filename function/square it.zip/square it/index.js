// var number =7;
// you have to write a logic to square it

// input 
// 7
// output 
// 49

let number = prompt("enter the number");
function square(number) {
    ans = number * number;
    console.log(ans);
}
square(number);





