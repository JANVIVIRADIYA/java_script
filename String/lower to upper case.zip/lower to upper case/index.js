function result(){
    var inputText=document.getElementById("inputText").value;
    var upperCaseText=inputText.toUpperCase();
    document.getElementById("output").innerHTML=upperCaseText;

}