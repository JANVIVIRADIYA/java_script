let one=1
let two=2
let three=3

let four=one*one+two*two+three*three

console.log(four);

