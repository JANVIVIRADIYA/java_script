// create a variable give a name, number then assign a value then after you have the check and print it if the value is odd print it's an odd number else it's an even number
// input
// 4
// output 
// it's an even number

function evenodd(){
    let number = 5;
    if (number%2==0){
        console.log("it is even number => ", number);
    }else{
        console.log("it is odd number =>"  , number);
    }

}
evenodd()