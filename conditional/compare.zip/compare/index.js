let num1 = 4
let num2 = 8
let num3 = 5


if (num1 > num2) {
   console.log("true");
}
else {
   console.log("false");
}

num1 = num1 + num2

if (num1 > num2) {
   console.log("true");
}
else {
   console.log("false");
}



