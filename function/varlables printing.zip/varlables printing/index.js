// Define a variable called the number  
// Initialise the number with the value 10
// Print the value stored in the variable number
// Assign the same variable number with 20
// Print the value stored in the variable number



function number(N) {
   console.log(N);
   number=20
   console.log(number);
}
number(10);