let a=2;
console.log(a*a*a);



