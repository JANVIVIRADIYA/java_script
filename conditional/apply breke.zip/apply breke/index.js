let distance=50
let time=15

let speed = distance/time
console.log(speed);

if(speed>40){
    console.log("Apply Brake");
}
else{
    console.log("Keep Going");
}