let a=4
let b=5
let c=8
let d=9
let sum=a+b+d-c

console.log(sum);
