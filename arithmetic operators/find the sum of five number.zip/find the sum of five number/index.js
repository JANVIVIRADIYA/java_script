let one=5
let two=5
let three=6
let four=9
let five=8

console.log(one+two+three+four+five);