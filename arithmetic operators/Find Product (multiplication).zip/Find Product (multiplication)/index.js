let one=6
let two=7
let three=8
let four=4
let five=9 

let product = one * two * three * four * five;

console.log(product);
