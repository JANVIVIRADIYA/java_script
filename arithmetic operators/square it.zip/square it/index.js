var number =7

console.log(number*number);