let N=prompt("enter number");
console.log(N);

if(N<13){
    console.log("your friends are 1 kms");
}
else if (N>=13 && N<18){
    console.log("your friends are 5 kms");
}
else if (N>=18 && N<30){
    console.log("your friends are 10 kms");
}
else{
    console.log("You can have friends from anywhere");
}

