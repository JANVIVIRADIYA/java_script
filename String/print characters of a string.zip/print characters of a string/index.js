function result(){
    var name = document.getElementById("name").value;{
        for(var i=0;i<name.length;i++){
            console.log(name[i])
        }
    }
   }
