
let num=10

for(let i=1; i<=num ; i++){
    console.log("RED and WHITE");
}

