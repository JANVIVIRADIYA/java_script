let num = prompt("enter the num")
let k = prompt("enter the k")

for(let i=1;i<=num;i++)
{
    if(i%k==0){
        console.log(i);
    }
}