// Create a variable name to store your name
// Create a variable age to store your age
// Print the values stored in the variable on one line followed by the type of           the variable in the next line

function NameAge(){
    let NAME = "janvi";
    let AGE = 24;
 console.log(NAME, AGE);
 console.log(typeof NAME, typeof AGE);
 
}
NameAge ();
